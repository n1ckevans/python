from django.apps import AppConfig


class RandomWordAppConfig(AppConfig):
    name = 'random_word_app'
